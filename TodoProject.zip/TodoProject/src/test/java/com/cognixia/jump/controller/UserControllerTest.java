package com.cognixia.jump.controller;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

//import javax.validation.Valid;
//import javax.websocket.server.PathParam;

import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
//import org.springframework.http.ResponseEntity;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;

//import com.cognixia.jump.model.AuthenticationRequest;
import com.cognixia.jump.model.Todo;
import com.cognixia.jump.model.User;
import com.cognixia.jump.model.User.Role;
//import com.cognixia.jump.service.UserService;

//import io.swagger.v3.oas.annotations.parameters.RequestBody;

@SpringBootTest(
		webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, 
		classes = UserController.class)
@AutoConfigureMockMvc
public class UserControllerTest {
	
	
	private final String STARTING_URI = "http://localhose:8080/api/";
	
	@Autowired
	private MockMvc mockMvc;
	
//	@MockBean
//	private UserService service; 
	
	@MockBean
	private UserController controller;

	private Set<Todo> tempTodoList = null;

	//TODO: Using Security -- Test API in UserController 
	
	//TODO: List<User> getAllUsers()
	// 			-- @GetMapping("/user")
	@Test
	@WithMockUser(roles = "USER")
	void testGetAllUsers() throws Exception {
		String uri = STARTING_URI + "/user";
		
		tempTodoList .add(new Todo(1L, "Grab Mail", false, LocalDate.parse("2021-10-07") ));
		tempTodoList .add(new Todo(2L, "Pick Up Food", true, LocalDate.parse("2021-10-07") ));
		tempTodoList .add(new Todo(3L, "Visit Grandma", false, LocalDate.parse("2021-10-10") ));

		
		List<User> allUsers = Arrays.asList(
				new User(1L,"user123", "happy", true, Role.ROLE_USER, tempTodoList ), 
				new User(2L,"user124", "sad", true, Role.ROLE_USER,tempTodoList ),
				new User(3L,"user125", "baby", true, Role.ROLE_USER, tempTodoList )
				);
		
		when(controller.getAllUsers()).thenReturn(allUsers);

		mockMvc.perform(get(uri))
					.andDo(print())
					.andExpect(status().isOk())
					.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
					.andExpect(jsonPath("$.length()").value(allUsers.size()) )
					.andExpect(jsonPath("$[1]").value(allUsers.get(1)))
					.andExpect(jsonPath("$[2]").value(allUsers.get(2)))
					.andExpect(jsonPath("$[3]").value(allUsers.get(3)));
		
		verify(controller, times(1)).getAllUsers();
		verifyNoMoreInteractions(controller);
		
	}
	
	//TODO: List<Todo> getUserTodos(@Valid @PathParam(value = "user_id") long id)
	// 			-- @GetMapping("/user/{id}/todo")
//	@Test
//	@WithMockUser(roles = "USER")
//	void testGetUserTodos() throws Exception {
//		String uri = STARTING_URI + "/user";
//		
//		User user = new User(1L,"user123", "happy", true, Role.ROLE_USER, tempTodoList );
//		
//		tempTodoList .add(new Todo(1L, "Grab Mail", false, LocalDate.parse("2021-10-07") ));
//		tempTodoList .add(new Todo(2L, "Pick Up Food", true, LocalDate.parse("2021-10-07") ));
//		tempTodoList .add(new Todo(3L, "Visit Grandma", false, LocalDate.parse("2021-10-10") ));
//
//		
//		when(controller.getUserTodos(user.getId())).thenReturn(tempTodoList);
////		Mockito.when(controller.getUserTodos(user.getId()).thenAnswer(x -> tempTodoList));
//		
//		mockMvc.perform(get(uri))
//					.andDo(print())
//					.andExpect(status().isOk())
//					.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
//					.andExpect(jsonPath("$.length()").value(tempTodoList.size()) )
//					.andExpect(jsonPath("$[1]").value(tempTodoList.getValue(1)))
//					.andExpect(jsonPath("$[2]").value(tempTodoList.get(2)))
//					.andExpect(jsonPath("$[3]").value(tempTodoList.get(3)));
//		
//		verify(controller, times(1)).getUserTodos(user.getId());
//		verifyNoMoreInteractions(controller);
//		
//	}
	
	//TODO: User getUserById(@Valid @PathVariable long id)
	// 			-- @GetMapping("/user/{id}")
	
	
	//TODO: ResponseEntity<?> addUser(@RequestBody AuthenticationRequest registeringUser)
	// 			-- @PostMapping("/user/add")
	
	
	//TODO: ResponseEntity<?> createAuthenticationToken(@RequestBody AuthenticationRequest authenticationRequest)
	// 			-- @PostMapping("/authenticate")
	
	
	
	//TODO: ResponseEntity<?> getByUsername(@Valid @PathVariable String username)
	// 			-- @GetMapping("/user/{username}")
	
	
	
	//TODO: ResponseEntity<?> getByUsernamePassword(@Valid @RequestBody AuthenticationRequest authenticationRequest)
	// 			-- @GetMapping("/user/login")
	
	
	//TODO: ResponseEntity<?> updateUser(@Valid @RequestBody AuthenticationRequest authenticationRequest)
	// 			-- @PutMapping("/user/update")
	
	
	
	//TODO: ResponseEntity<?> deleteUser(@Valid @RequestBody AuthenticationRequest authenticationRequest)
	// 			-- @DeleteMapping("/user/delete")
	
	
	
	//TODO: ResponseEntity<?> addUserTodo(@Valid @PathParam(value = "user_id")
	// 			-- @PostMapping("/user/{id}/todo/add")
	
	
	//TODO: ResponseEntity<?> updateAllUserTodoCompletion(@Valid @PathParam(value= "id") long id, 
	// 											@PathParam(value="completion") boolean completion) 
	// 			-- @PutMapping("/user/{id}/todo/update/{completion}")
	
	
	
	//TODO: ResponseEntity<?> deleteTodoOfUser(@Valid @PathParam(value = "user_id") long id, 
	// 											@PathParam(value= "todo_id") long todoId)
	// 			-- @DeleteMapping("/user/{id}/todo/delete/{todoId}")
	
	
	
	//TODO: ResponseEntity<?> deleteUserTodos(@Valid @PathParam(value = "user_id") long id)
	// 			-- @DeleteMapping("/user/{id}/todo/delete")
	
	
	
}
