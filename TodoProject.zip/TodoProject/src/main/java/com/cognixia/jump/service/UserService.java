package com.cognixia.jump.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cognixia.jump.exception.ResourceNotFoundException;
import com.cognixia.jump.exception.UserAlreadyExistsException;
import com.cognixia.jump.model.AuthenticationRequest;
import com.cognixia.jump.model.User;
import com.cognixia.jump.model.User.Role;
import com.cognixia.jump.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	UserRepository userRepository; 
	
	@Autowired
	PasswordEncoder passwordEncoder; 
	
	public boolean createNewUser(AuthenticationRequest registeringUser) throws Exception {
		
		Optional<User> isAlreadyRegistered = userRepository.findByUsername(registeringUser.getUsername());
		
		if(isAlreadyRegistered.isPresent()) {
			throw new UserAlreadyExistsException(registeringUser.getUsername());
			
		}
		
		User newUser = new User(); 
		newUser.setUsername(registeringUser.getUsername()); 
		newUser.setPassword(passwordEncoder.encode(registeringUser.getPassword())); 
		newUser.setEnabled(true);
		newUser.setRole(Role.valueOf("ROLE_USER"));
		
		userRepository.save(newUser);
		return true;
	}

	//TODO: PUT - Update User
	public User updateUser(AuthenticationRequest updatingUser) throws ResourceNotFoundException{
		
		Optional<User> found = userRepository.findByUsername(updatingUser.getUsername());

		if(found.isPresent()) {
			
			User updated = new User(); 
			updated.setUsername(updatingUser.getUsername()); 
			updated.setPassword(passwordEncoder.encode(updatingUser.getPassword())); 
			updated.setEnabled(true);
			updated.setRole(Role.valueOf("ROLE_USER"));
			
			return userRepository.save(updated);
			
		}
		
		throw new ResourceNotFoundException("User");
	}
	
	
	//TODO: DELETE - Delete User 
	public User deleteUser(AuthenticationRequest deletingUser) throws ResourceNotFoundException{
		
		Optional<User> found = userRepository.findByUsername(deletingUser.getUsername());

		if(found.isPresent()) {
			userRepository.delete(found.get());
			
			return found.get();
		}
		
		throw new ResourceNotFoundException("User");

	}
	

}
