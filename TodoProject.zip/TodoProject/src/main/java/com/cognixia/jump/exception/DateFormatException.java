package com.cognixia.jump.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value=HttpStatus.CONFLICT)
public class DateFormatException extends Exception {

	private static final long serialVersionUID = 1L;

	public DateFormatException() {
		super("The date you entered is invalid. Please follow the format 'yyyy-mm-dd' ");
	}
}
