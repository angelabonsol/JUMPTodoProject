package com.cognixia.jump.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognixia.jump.model.Todo;

@Repository
public interface TodoRepository extends JpaRepository<Todo, Long>{

//	@Query("SELECT t FROM Todo t WHERE t.id = ?1")
//	Todo findById(long id);
	
	@Query("SELECT t FROM Todo t WHERE t.ifCompleted = ?1")
	List<Todo> findByCompleted(boolean complete);

	@Query("SELECT t FROM Todo t WHERE t.date = ?1")
	List<Todo> findByDueDates(LocalDate date);
	
//	@Query("UPDATE Todo t SET t.ifCompleted = ?2 WHERE t.id = ?1")
//	Todo updateTodoCompletion(long id, boolean completion);	

}
