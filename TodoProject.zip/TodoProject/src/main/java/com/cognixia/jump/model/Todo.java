package com.cognixia.jump.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

@Entity
public class Todo {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name= "todo_id")
	private Long id;
	
	@NotNull(message = "Please describe your task")
	@Column(name="description")
	private String description; 
	
	@Column(name= "ifCompleted")
	private boolean ifCompleted; 
	
//	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd-MM-yyyy")
	@Column(name="date")
	private LocalDate date;
	
	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;


	public Todo()  {
		this( -1L, "N/A", false, LocalDate.now());
	}

	public Todo(Long id, @NotNull(message = "Please describe your task") String description, boolean ifCompleted,
			LocalDate date) {
		super();
		this.id = id;
		this.description = description;
		this.ifCompleted = ifCompleted;
		this.date = date;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isIfCompleted() {
		return ifCompleted;
	}

	public void setIfCompleted(boolean ifCompleted) {
		this.ifCompleted = ifCompleted;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}
	
	public String toJson() {
		
		return "{\"id\" : " + id
				+ ", \"description\" : \"" + description + "\""
				+ ", \"ifCompleted\" : \"" + ifCompleted + "\""
				+ ", \"date\" : \"" + date + "\"" +
		"}";
	}

	@Override
	public String toString() {
		return "Todo [id=" + id + ", description=" + description + ", ifCompleted=" + ifCompleted + ", date=" + date
				+ "]";
	}
	
}

