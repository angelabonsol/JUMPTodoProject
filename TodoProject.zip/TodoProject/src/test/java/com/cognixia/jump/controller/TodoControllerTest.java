package com.cognixia.jump.controller;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

//import javax.validation.Valid;
//import javax.websocket.server.PathParam;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
//import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PatchMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestParam;

import com.cognixia.jump.exception.ResourceNotFoundException;
import com.cognixia.jump.model.Todo;
import com.cognixia.jump.service.TodoService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


@ExtendWith(SpringExtension.class)
@WebMvcTest(TodoController.class)
public class TodoControllerTest {

	
	private final String STARTING_URI = "http://localhose:8080/api/";
	
	@Autowired
	private MockMvc mockMvc;
	 
	@MockBean
	private TodoService service; 
	
	@InjectMocks
	private	TodoController controller;
	
	//TODO: List<Todo> getAllTodos() -- @GetMapping("/todo")
	@Test
	void testGetAllTodos() throws Exception {
		String uri = STARTING_URI + "/todo";
		
		List<Todo> allTodos = Arrays.asList(
				new Todo(1L,"Call Evan", false, LocalDate.parse("2021-10-03")), 
				new Todo(2L,"Water Plants", false, LocalDate.parse("2021-10-05")),
				new Todo(3L,"Math Project Due", false, LocalDate.parse("2021-10-06"))
				);
		
		when(service.getAllTodos()).thenReturn(allTodos);

		mockMvc.perform(get(uri))
					.andDo(print())
					.andExpect(status().isOk())
					.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
					.andExpect(jsonPath("$.length()").value(allTodos.size()) )
					.andExpect(jsonPath("$[1]").value(allTodos.get(1)))
					.andExpect(jsonPath("$[2]").value(allTodos.get(2)))
					.andExpect(jsonPath("$[3]").value(allTodos.get(3)));
		
		verify(service, times(1)).getAllTodos();
		verifyNoMoreInteractions(service);
		
	}
	
	
	//TODO: Todo getTodoById(@PathVariable long id) 
	// 			-- @GetMapping("/todo/{id}")
	@Test
	void testGetTodoById() throws Exception{
		
		long id = 3;

		String uri = STARTING_URI + "/todo/" + id;
		
		Todo todo = new Todo(id, "Pick up package", false, LocalDate.parse("2021-10-06"));
		
		todo.setId(id);
		
		GsonBuilder builder = new GsonBuilder();
		builder.setPrettyPrinting();
		Gson gson = builder.create();
		
		String todoJSON = gson.toJson(todo);
		
		when(service.getTodoById(id)).thenReturn(todo);
		
		mockMvc.perform(get(uri, id))
		.andDo(print())
		.andExpect(status().isOk())
		.andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
		.andExpect(content().json(todoJSON));
		
		verify(service, times(1)).getTodoById(id);
		verifyNoMoreInteractions(service);
		
	}
	
	//TODO: ResourceNotFoundException
	@Test
	void testGetTodoNotFoundException() throws Exception{
		
		long id = 1; 
		String uri = STARTING_URI + "/todo/" + id;
		Exception exception = new ResourceNotFoundException("Todo with id: " + id + " is not found.");
		
		when(service.getTodoById(id)).thenThrow(exception);
		
		mockMvc.perform(get(uri, id))
				.andDo(print())
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("$.message").value(exception.getMessage()));
		
		// clean up and verification 
		verify(service, times(1)).getTodoById(id);
		verifyNoMoreInteractions(service);
		
	}
	
	//TODO: ResponseEntity<Todo> createTodo(@Valid @RequestBody Todo task) 
	// 			-- @PostMapping("/todo/add")
	@Test
	void testCreateTodo() throws Exception{
		
		long id = 1;
		
		String uri = STARTING_URI + "/todo/add";
		
		Todo todo = new Todo(id, "Pick up package", false, LocalDate.parse("2021-10-06"));
				
		String todoJson = todo.toJson();
		
		when(service.addTodo(Mockito.any(Todo.class))).thenReturn(todo);
		
		
		mockMvc.perform(post(uri).content(todoJson)
							.contentType(MediaType.APPLICATION_JSON))
							.andDo(print())
							.andExpect(status().isCreated())
							.andExpect(content().contentType(MediaType.APPLICATION_JSON));
	
		verify(service, times(1)).addTodo(todo);
		verifyNoMoreInteractions(service);
		
	}
	
	
	//TODO: ResponseEntity<Todo> updateTodo(@Valid @RequestBody Todo task) 
	//			-- @PutMapping("/todo/update")
	@Test
	void testUpdateTodo() throws Exception{

		long id = 1;

		String uri = STARTING_URI + "/todo/update";
		
		Todo todo = new Todo(id, "Pick up package", false, LocalDate.parse("2021-10-06"));
		
		Todo updated = new Todo(id, "Pick up package at Amazon", false, LocalDate.parse("2021-10-06"));

		String updateJson = updated.toJson();
		
	
		when(service.updateTodo(updated)).thenReturn(updated);
		
		
		mockMvc.perform(post(uri).content(updateJson)
							.contentType(MediaType.APPLICATION_JSON))
							.andDo(print())
							.andExpect(status().isOk())
							.andExpect(content().contentType(MediaType.APPLICATION_JSON));
	
		verify(service, times(1)).updateTodo(todo);
		verifyNoMoreInteractions(service);
		
	}
	
	
	//TODO: ResponseEntity<Todo> removeTodo(@PathVariable long id) 
	//			-- @DeleteMapping("/todo/delete/{id}")
//	@Test
//	void testRemoveTodo() throws Exception{
//		
//		long id = 1;
//
//		String uri = STARTING_URI + "/todo/delete/" + id;
//
//		
//		
//		
//		
//		
//	}
	
	
	//TODO: ResponseEntity<Todo> updateCompletion(@Valid @PathParam(value = "id") long id, 
	//											@Valid @RequestParam(value = "ifCompleted")
	// 			-- @PatchMapping("/todo/update/complete")
//	@Test
//	void testUpdateCompletion() throws Exception{
//
//		String uri = STARTING_URI + "/todo/update/complete";
//
//		
//		
//		
//		
//		
//	}
	
	
	//TODO: ResponseEntity<Todo> updateDueDate(@Valid @PathParam(value = "id") long id, 
	// 											@RequestParam(value = "date")
	//  		-- @PatchMapping("/todo/update/duedate")
//	@Test
//	void testUpdateDueDate() throws Exception{
//
//		String uri = STARTING_URI + "/todo/update/duedate";
//
//		
//		
//		
//		
//		
//	}
	
	
	//TODO: List<Todo> deleteAllTodos() 
	// 			-- @DeleteMapping("/todo/delete/all")
//	@Test
//	void testDeleteAllTodos() throws Exception{
//
//		String uri = STARTING_URI + "/todo/delete/all";
//
//		
//		
//		
//		
//		
//	}
	
	//TODO: List<Todo> updateAllTodosCompletion(@Valid @RequestParam(value = "ifCompleted") 
	// 															boolean completion)
	// 			-- @PatchMapping("/todo/update/all/completion")
//	@Test
//	void testUpdateAllToddosCompletion() throws Exception{
//
//		String uri = STARTING_URI + "/todo/update/all/completion";
//
//		
//		
//		
//		
//		
//	}
	
	
	//TODO: List<Todo> getTodosDueDate(@PathVariable String date) 
	// 			-- @GetMapping("/todo/duedate/{date}")
//	@Test
//	void testGetTodosDueDate() throws Exception{
//
//		String date = "2021-10-06"; 
//		
//		String uri = STARTING_URI + "/todo/duedate/" + date;
//
//		
//		
//		
//		
//		
//	}
	
	//TODO: List<Todo> getTodosCompletion(@PathVariable boolean complete) 
	// 			-- @GetMapping("/todo/completion/{complete}")
//	@Test
//	void testGetTodosCompletion() throws Exception{
//		
//		String complete = "true";
//
//		String uri = STARTING_URI + "/todo/completion/" + complete;
//
//		
//		
//		
//		
//		
//	}


	
}
