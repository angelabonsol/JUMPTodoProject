package com.cognixia.jump.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognixia.jump.exception.ResourceNotFoundException;
import com.cognixia.jump.exception.WrongPasswordException;
import com.cognixia.jump.model.AuthenticationRequest;
import com.cognixia.jump.model.AuthenticationResponse;
import com.cognixia.jump.model.Todo;
import com.cognixia.jump.model.User;
import com.cognixia.jump.repository.UserRepository;
import com.cognixia.jump.service.MyUserDetailsService;
import com.cognixia.jump.service.TodoService;
import com.cognixia.jump.service.UserService;
import com.cognixia.jump.util.JwtUtil;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RequestMapping("/api")
@RestController
public class UserController {
	
	@Autowired
	UserRepository userRepository; 
	
	@Autowired
	UserService userService; 
	
	@Autowired
	private AuthenticationManager authenticationManager; 
	
	@Autowired 
	private MyUserDetailsService myUserDetailsService;
	
	@Autowired 
	private JwtUtil jwtTokenUtil; 
	
	@Autowired
	TodoService todoService;

	private List<Todo> userTodos = null;
	
	@GetMapping("/user")
	public List<User> getAllUsers(){
		return userRepository.findAll();
	}
	
	//TODO: GET - All Todos of User -- USER IN USE
	@GetMapping("/user/{id}/todo")
	public List<Todo> getUserTodos(@Valid @PathParam(value = "user_id") long id){
		
		List<Todo> allTodos = todoService.getAllTodos();
		
		for (Todo t: allTodos) {
			if(t.getUser().getId() == id)
				userTodos.add(t);
		}
		
		return userTodos;
	}
	
	@GetMapping("/user/{id}")
	public User getUserById(@Valid @PathVariable long id) throws ResourceNotFoundException {
		Optional<User> found = userRepository.findById(id);
		
		if(found == null) {
			throw new ResourceNotFoundException("User", id);
		}
						
		return found.get();
	}
	
	@PostMapping("/user/add")
	public ResponseEntity<?> addUser(@RequestBody AuthenticationRequest registeringUser) throws Exception {
		
		userService.createNewUser(registeringUser);
		
		return ResponseEntity.ok(registeringUser.getUsername() + " has been created.");
		
	}
	
	@PostMapping("/authenticate")
	public ResponseEntity<?> createAuthenticationToken(@RequestBody AuthenticationRequest authenticationRequest) throws Exception{
		
		try {
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(
							authenticationRequest.getUsername(),
							authenticationRequest.getPassword())
					);
			
		} catch(BadCredentialsException e) {
			throw new Exception("Incorect Username or password. ", e);
		}catch(Exception e) {
			throw new Exception(e);
		}
		
		final UserDetails USER_DETAILS = myUserDetailsService 
				.loadUserByUsername(authenticationRequest.getUsername());
		
		final String JWT = jwtTokenUtil.generateTokens(USER_DETAILS);
		
		return ResponseEntity.ok(new AuthenticationResponse(JWT));
		
	}
		
	//TODO: GET - Get User By Username -- ALL 
	@GetMapping("/user/{username}")
	public ResponseEntity<?> getByUsername(@Valid @PathVariable String username){

		final UserDetails USER_DETAILS = myUserDetailsService 
				.loadUserByUsername(username);
		
		final String JWT = jwtTokenUtil.generateTokens(USER_DETAILS);
		
		return ResponseEntity.ok(new AuthenticationResponse(JWT));
	
	}
	
	//TODO: GET - Get User By Username and Password -- ADMIN & USER IN USE
	@GetMapping("/user/login")
	public ResponseEntity<?> getByUsernamePassword(@Valid @RequestBody AuthenticationRequest authenticationRequest) throws UsernameNotFoundException, WrongPasswordException{

		final UserDetails USER_DETAILS = myUserDetailsService 
				.loadUserByUsernamePassword(authenticationRequest.getUsername(), authenticationRequest.getPassword());
				
		return ResponseEntity.ok(USER_DETAILS);
	}
	
	//TODO: PUT - Update User -- USER IN USE
	@PutMapping("/user/update")
	public ResponseEntity<?> updateUser(@Valid @RequestBody AuthenticationRequest authenticationRequest) throws ResourceNotFoundException{

		final User update = userService.updateUser(authenticationRequest);
		
		return ResponseEntity.ok(update);
	}

	//TODO: DELETE - Delete User -- USER IN USE
	@DeleteMapping("/user/delete")
	public ResponseEntity<?> deleteUser(@Valid @RequestBody AuthenticationRequest authenticationRequest) throws ResourceNotFoundException{

		final User delete = userService.deleteUser(authenticationRequest);

		return ResponseEntity.ok(delete.getUsername() + " has been deleted.");	
	}
	
	//TODO: POST - Create New Todo for User -- USER IN USE
	@PostMapping("/user/{id}/todo/add")
	public ResponseEntity<?> addUserTodo(@Valid @PathParam(value = "user_id") long id, @RequestBody Todo task) throws Exception {
		
		Todo toAdd = todoService.addTodo(task); 
		toAdd.setUser(getUserById(id));
				
		return ResponseEntity.ok(todoService.updateTodo(toAdd));
		
	}
	
	//TODO: PATCH - Update All Todos Completion -- USER IN USE
	@PutMapping("/user/{id}/todo/update/{completion}")
	public ResponseEntity<?> updateAllUserTodoCompletion(@Valid @PathParam(value= "id") long id, @PathParam(value="completion") boolean completion) throws ResourceNotFoundException{
		
		List<Todo> allTodos = getUserTodos(id);
		
		for(Todo t: allTodos) {
			t = todoService.updateCompletion(t.getId(), completion);
		}

		return ResponseEntity.ok("All todos of User with id= " + id + " has been marked " + completion);	
	}
	
	//TODO: DELETE - A todo of User -- USER IN USE
	@DeleteMapping("/user/{id}/todo/delete/{todoId}")
	public ResponseEntity<?> deleteTodoOfUser(@Valid @PathParam(value = "user_id") long id, @PathParam(value= "todo_id") long todoId) throws ResourceNotFoundException{
		
		List<Todo> allTodos = getUserTodos(id);
		
		for (Todo t: allTodos) {
			if(t.getId() == todoId)
				todoService.deleteTodo(todoId);
		}
		
		return ResponseEntity.ok("Todo with id=" + todoId + " of User with id= " + id + " has been deleted");
	}
	
	//TODO: DELETE - All Todos of User -- USER IN USE
	@DeleteMapping("/user/{id}/todo/delete")
	public ResponseEntity<?> deleteUserTodos(@Valid @PathParam(value = "user_id") long id) throws ResourceNotFoundException{

		List<Todo> toDelete = getUserTodos(id);
		
		for(Todo t: toDelete)
			todoService.deleteTodo(t.getId());

		return ResponseEntity.ok("Todo List of user " + getUserById(id).getUsername() + " has been deleted.");	
	}
	
	
	
}
