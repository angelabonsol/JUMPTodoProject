package com.cognixia.jump.controller;

import java.util.List;

import javax.validation.Valid;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cognixia.jump.exception.DateFormatException;
import com.cognixia.jump.exception.ResourceAlreadyExistsException;
import com.cognixia.jump.exception.ResourceNotFoundException;
import com.cognixia.jump.model.Todo;
import com.cognixia.jump.service.TodoService;

import io.swagger.annotations.ApiOperation;

@ApiOperation(value = "Controller for accessing Todo data.")
@RequestMapping("/api")
@RestController
public class TodoController {

	@Autowired
	TodoService service; 
	
	@ApiOperation(value = "Get a list of all Todos.")
	@GetMapping("/todo")
	public List<Todo> getAllTodos(){
		return service.getAllTodos();
	}
	
	@ApiOperation(value = "Get Todo by id.")
	@GetMapping("/todo/{id}")
	public Todo getTodoById(@PathVariable long id) throws ResourceNotFoundException{
		return service.getTodoById(id);
	}
	
	@PostMapping("/todo/add")
	public ResponseEntity<Todo> createTodo(@Valid @RequestBody Todo task) throws ResourceAlreadyExistsException{
		Todo added = service.addTodo(task);
		
		return new ResponseEntity<Todo>(added, HttpStatus.CREATED);
	}
	
	@PutMapping("/todo/update")
	public ResponseEntity<Todo> updateTodo(@Valid @RequestBody Todo task) throws ResourceNotFoundException{
		Todo updated = service.updateTodo(task);

		return new ResponseEntity<Todo>(updated, HttpStatus.OK); 
	}
	
	@DeleteMapping("/todo/delete/{id}")
	public ResponseEntity<Todo> removeTodo(@PathVariable long id) throws ResourceNotFoundException{
		Todo deleted = service.deleteTodo(id);
		
		return new ResponseEntity<Todo>(deleted, HttpStatus.OK); 
	}

	//TODO: PATCH Update Completion
	@PatchMapping("/todo/update/complete")
	public ResponseEntity<Todo> updateCompletion(@Valid @PathParam(value = "id") long id, @Valid @RequestParam(value = "ifCompleted") boolean completion) throws ResourceNotFoundException{	
		Todo completed = service.updateCompletion(id, completion); 
		
		return new ResponseEntity<Todo>(completed, HttpStatus.OK); 
	}
	
	//TODO: PATCH Update Due Date
	@PatchMapping("/todo/update/duedate")
	public ResponseEntity<Todo> updateDueDate(@Valid @PathParam(value = "id") long id, @RequestParam(value = "date") String date) throws ResourceNotFoundException, DateFormatException{
		Todo changedDate = service.updateDueDate(id, date); 
		
		return new ResponseEntity<Todo>(changedDate, HttpStatus.OK); 
	}
	
	//TODO: Delete All Todos
	@DeleteMapping("/todo/delete/all")
	public List<Todo> deleteAllTodos() {
		return service.deleteAllTodos();
	}

	//TODO: Update All Todos Completion
	@PatchMapping("/todo/update/all/completion")
	public List<Todo> updateAllTodosCompletion(@Valid @RequestParam(value = "ifCompleted") boolean completion){
		return service.updateAllTodosCompletion(completion);
	}
	
	//TODO: GET by Due Dates 
	@GetMapping("/todo/duedate/{date}")
	public List<Todo> getTodosDueDate(@PathVariable String date) throws ResourceNotFoundException, DateFormatException{
		return service.getTodosOfDueDate(date);
	}
	
	//TODO: GET by Completion 
	@GetMapping("/todo/completion/{complete}")
	public List<Todo> getTodosCompletion(@PathVariable boolean complete) throws ResourceNotFoundException{
		return service.getTodosOfCompleted(complete);
	}
		
}
