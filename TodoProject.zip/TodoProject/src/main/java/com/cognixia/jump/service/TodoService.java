package com.cognixia.jump.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognixia.jump.exception.DateFormatException;
import com.cognixia.jump.exception.ResourceNotFoundException;
import com.cognixia.jump.model.Todo;
import com.cognixia.jump.repository.TodoRepository;

@Service
public class TodoService {
	
	@Autowired
	TodoRepository repo;
	
	public List<Todo> getAllTodos(){
		return repo.findAll();
	}
	
	public Todo getTodoById(long id) throws ResourceNotFoundException {
		
		Optional<Todo> found = repo.findById(id);
		
		if(found == null) {
			throw new ResourceNotFoundException("Todo", id);
		}
						
		return found.get();
	}
	
	public Todo addTodo(Todo task){
		
		task.setId(-1L);
		
		Todo addTask = repo.save(task);
		
		return addTask;
		
	}
	
	public Todo updateTodo(Todo task) throws ResourceNotFoundException {
		
		if(repo.existsById(task.getId())) {
			
			Todo updated = repo.save(task);
			
			return updated;
		}
		
		throw new ResourceNotFoundException("Todo to Update", task.getId());
	    
	}
	
	public Todo deleteTodo(long id) throws ResourceNotFoundException {
	
		Todo deleteTask = getTodoById(id);
		
		repo.deleteById(id);
		
		return deleteTask;
	}
	
	//TODO: Update all Todos to Complete
	public List<Todo> updateAllTodosCompletion(boolean completion){
		
		List<Todo> todos = getAllTodos();
		
		for(Todo t: todos) {
			t.setIfCompleted(completion);
			repo.save(t);
		}
		
		return todos;
	}

	//TODO: Delete all Todos
	public List<Todo> deleteAllTodos(){
		
		List<Todo> todos = getAllTodos();
		
		for(Todo t: todos) {
			repo.deleteById(t.getId());
		}
		
		return todos;
		
	}
	
	//TODO: Update Completed/not Completed
	public Todo updateCompletion (long id, boolean completion) throws ResourceNotFoundException {

		if(repo.existsById(id)) {
			
			Todo toUpdate = getTodoById(id);
			
			toUpdate.setIfCompleted(completion);
				
			return repo.save(toUpdate);
		}
		
		throw new ResourceNotFoundException("Task to Update Due Date", id);

	}
	
	//TODO: Update DueDate -- to SQL
	public Todo updateDueDate(long id, String date) throws ResourceNotFoundException, DateFormatException{
		Optional<Todo> found = repo.findById(id);
		
		if(date.length() > 9)
			throw new DateFormatException();
		
		LocalDate thisDate = LocalDate.parse(date);
				
		if(found.isPresent()) {
			 
			Todo toUpdate = found.get(); 
			
			toUpdate.setDate(thisDate);
			
			Todo updated = repo.save(toUpdate);
			
			return updated;
		}
		
		throw new ResourceNotFoundException("Task to Update Due Date", id);
	}
	
	//TODO: Get By Due Date 
	public List<Todo> getTodosOfDueDate(String date) throws DateFormatException{	
		if(date.length() > 9)
			throw new DateFormatException();
		
		return repo.findByDueDates(LocalDate.parse(date));
	}
	
	//TODO: Get Completed/not Completed 
	public List<Todo> getTodosOfCompleted(boolean complete){
		return repo.findByCompleted(complete);
	}
	
}
